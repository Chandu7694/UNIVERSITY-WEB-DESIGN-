# html-css-js-project-boilerplate
HTML CSS mini project using html, css, and bootstrap for Assignment of Newton School

Link of Website : 
https://github.com/anjali-garg3112/HTML-CSS-Project---HTML-CSS-Mini-Project---9c7w7p0sg2uc


HTML file inculdes:
1. Used fontawesome link to add unique icons to my webpage. example- facebook, instagram, heart
2. made my icons clickable using OnClick.
3.used <div> tag to maintain needed space for each item.
4. used <img> tag to add beautiful images to my website

CSS effects:
1. I Have used link tag to link my css to html files.
2. I have used Anchor tag
3. I have used Hover effect
4. I have used Media queries to make my website look responsive, i.e. depending on the screen size that creates dynamic changes to th appearance of a website.
5. I have used font family tag to give different styling to the texts.


About project
I have made a university website using Html and CSS with Visual Studio Code(code editor) , it is simply a university page that helps their students as well as potential
students to get to know about them and the services they offer. 
One could easily contact the faculty if needed, they could get themselves enrolled through the website.

